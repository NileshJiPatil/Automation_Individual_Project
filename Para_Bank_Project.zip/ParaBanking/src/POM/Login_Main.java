package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Program.Pom;

public class Login_Main {

	public static void main(String[] args) {
		
				System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Documents\\AutomationTesting\\Browser_Extension\\chromedriver.exe");
				WebDriver driver =new ChromeDriver();
				Pom obj=new Pom();
				obj.url(driver);
				obj.maximizeBrowser(driver);
				obj.enterUsername(driver, "john");
		        obj.enterPassword(driver, "demo");
		        obj.clickOnLoginButton(driver);
		        obj.clickOnLogOutButton1(driver);
		        
		        
		        obj.closeBrowser(driver);
	}

}
