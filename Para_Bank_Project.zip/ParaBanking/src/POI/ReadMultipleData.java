package POI;

import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadMultipleData {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		//step1-Create object of FileInputStream>>To store file path
		FileInputStream file=new FileInputStream("C:\\Users\\admin\\Documents\\AutomationTesting\\POI\\POI_FrameworksPara.xlsx");
//step2-create object of XSSFWorkbook>>Excel Sheet File
		XSSFWorkbook w= new XSSFWorkbook(file);
		//step 3-create object  of XSSSFWorkbook
		XSSFSheet s=w.getSheet("ReadMultipleData");
		//Store no of row in variable
		int rowsize=s.getLastRowNum();
		System.out.println("No of Data:"+rowsize);
		//for loop for rows
		for(int i=0;i<rowsize;i++)
		{
			String name=s.getRow(i).getCell(0).getStringCellValue();
			String loc=s.getRow(i).getCell(1).getStringCellValue();
			System.out.println(name+"\t\t"+loc);
		}
		
	}

}
