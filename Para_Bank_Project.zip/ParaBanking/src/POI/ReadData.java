package POI;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadData {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//step1-Create object of FileInputStream>>To store file path
		FileInputStream file=new FileInputStream("C:\\Users\\admin\\Documents\\AutomationTesting\\POI\\POI_FrameworksPara.xlsx");
//step2-create object of XSSFWorkbook>>Excel Sheet File
		XSSFWorkbook w= new XSSFWorkbook(file);
		//step 3-create object  of XSSSFWorkbook
		XSSFSheet s=w.getSheet("ReadData");
		
		//step4-Rows+Cell
		String a=s.getRow(0).getCell(0).getStringCellValue();
		String b=s.getRow(0).getCell(1).getStringCellValue();
		int c= (int) s.getRow(0).getCell(2).getNumericCellValue();
		//step5-Display Data
		System.out.println(a+"\t\t"+b+"\t\t"+c);

	}

}
