package Keyword_Driven;

import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;


//import KeywordDriven.Operationalclass;

public class ReadExcel1 {

	public  void readExcel(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		FileInputStream file = new FileInputStream("./POI.xlsx");
		XSSFWorkbook w=new XSSFWorkbook(file);
		XSSFSheet s =w.getSheet("Sheet1");

		int rowsize=s.getLastRowNum();
		System.out.println("No of Keywords: "+rowsize);

		Operational o=new Operational();

		for(int i=1;i<=rowsize;i++) {
			String Key=s.getRow(i).getCell(0).getStringCellValue();
			System.out.println(Key);

			if(Key.equals("OpenURL"))
			{
				o.url(driver);
				Thread.sleep(2000);

			}

			else if(Key.equals("MaximizeBrowser"))

			{
				o.maximizeBrowser(driver);



			}

			else if(Key.equals("EnterUsername"))
			{
				o.enterUsername(driver, "john");
			}
			else if(Key.equals("EnterPassword"))
			{
				o.enterPassword(driver, "demo");
			}

			else if(Key.equals("ClickOnLoginButton"))
			{
				o.clickOnLoginButton(driver);
				Thread.sleep(2000);
			}
			else if(Key.equals("ClickOnLogoutButton"))
			{
				o.clickOnLogOutButton(driver);
				Thread.sleep(2000);
			}
			else if(Key.equals("CloseBrowser"))
			{
				o.closeBrowser(driver);
				Thread.sleep(2000);
			}







		}}}



