package Program;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Title_verification {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Documents\\AutomationTesting\\Browser_Extension\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Pom obj=new Pom();
		obj.url(driver);
		Thread.sleep(2000);
		obj.maximizeBrowser(driver);
		driver.manage().deleteAllCookies();
		//task 1: Title Verification
		// System.out.println(driver.getCurrentUrl());
		//System.out.println(driver.getTitle());  
		String acceptedTitle="Register for Free Online Account Access";
		String actualTitle=driver.getTitle();
		if(actualTitle.equals(acceptedTitle)) 
		{
			System.out.println("Title Verification Passed");
		}
		else
		{
			System.out.println("Title Verification failed");
		}
		// task 2: Navigation Comands
		driver.findElement(By.xpath("//a[@href='http://forums.parasoft.com/']")).click();
	     
		Thread.sleep(2000);
        driver.navigate().back();
        Thread.sleep(2000);
        driver.navigate().forward();
        Thread.sleep(2000);
        driver.navigate().refresh();
        Thread.sleep(2000);
        driver.navigate().to("https://parabank.parasoft.com/parabank/register.htm");
        
	}

}

