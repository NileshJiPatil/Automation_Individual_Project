package Program;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_Logout {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Documents\\AutomationTesting\\Browser_Extension\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Pom obj=new Pom();
		obj.url(driver);
		obj.maximizeBrowser(driver);
		obj.enterUsername(driver, "john");
        obj.enterPassword(driver, "demo");
        obj.clickOnLoginButton(driver);
        
        
        obj.closeBrowser(driver);
	}

}
