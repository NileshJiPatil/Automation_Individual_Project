package Program;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class nav {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Documents\\AutomationTesting\\Browser_Extension\\\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();

		//URL
		driver.get("https://parabank.parasoft.com/parabank/register.htm");
		//maximize
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getTitle());
	}

}
