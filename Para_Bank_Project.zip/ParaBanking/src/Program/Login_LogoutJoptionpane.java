package Program;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_LogoutJoptionpane {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Documents\\AutomationTesting\\Browser_Extension\\\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();

		//URL
		driver.get("https://parabank.parasoft.com/parabank/register.htm");
		//maximize
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		String usn=JOptionPane.showInputDialog("Enter Username");
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("john");
		Thread.sleep(2000);
		
		String pwd=JOptionPane.showInputDialog("Enter Password");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("demo");
		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(2000);

		//driver.findElement(By.xpath("//a[@href='/parabank/logout.htm']")).click();

		driver.close();







	}

}
