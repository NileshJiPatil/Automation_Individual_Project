
package Program;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Cross_Browser {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		Scanner s= new Scanner(System.in);
		System.out.println("Enter:1 for Chrome/n Enter:3 for Firefox");
		int input=s.nextInt();
		WebDriver driver=null;
		
		
		switch(input)
		 {
		 case 1:
			 System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Documents\\AutomationTesting\\Browser_Extension\\chromedriver.exe");
			 driver =new ChromeDriver();
			 
	     break;
		 case 2:
		 System.setProperty("webdriver.gecko.driver", "C:\\Users\\admin\\Documents\\AutomationTesting\\Browser_Extension\\geckodriver.exe");
		 driver =new ChromeDriver();
		 break;
		 
		 default:
			 System.out.println("Invalid Selection");
		 }
		Pom obj=new Pom();
		obj.url(driver);
		Thread.sleep(2000);
		obj.maximizeBrowser(driver);
		Thread.sleep(2000);
		obj.closeBrowser(driver);
	}

}
