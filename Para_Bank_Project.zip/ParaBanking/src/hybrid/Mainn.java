package hybrid;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Mainn {
	 public static void main(String args) throws Exception {
		  
			//launch browser
			  System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Documents\\AutomationTesting\\Browser_Extension\\chromedriver.exe");
				WebDriver driver=new ChromeDriver();
				Thread.sleep(3000);
				
				//create object of ReadExcelClass
				Hy_ReadExcel r= new Hy_ReadExcel();
				r.readExcel(driver);

}}
