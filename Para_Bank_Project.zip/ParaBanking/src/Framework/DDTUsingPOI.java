package Framework;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Program.Pom;

public class DDTUsingPOI {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		FileInputStream file= new FileInputStream("./POI_FrameworksPara.xlsx");
		// Jvm reach the file
		XSSFWorkbook w= new XSSFWorkbook(file);
		//decide unique excel sheet
		XSSFSheet s=w.getSheet("DataDriven");
		// to store total no of row
		int rowsize=s.getLastRowNum();
		//launch the browser
		  System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Documents\\AutomationTesting\\Browser_Extension\\chromedriver.exe");
		    // Step2:create object of webdriver to Chromedriver
		    WebDriver driver=new ChromeDriver();     // create object of POM class
			Pom obj=new Pom();
			 // for loop
		    for(int i=1;i<=rowsize;i++)
		    {
		    	//Store username and password in veriables
		    	String username=s.getRow(i).getCell(0).getStringCellValue();
		    	String Password=s.getRow(i).getCell(1).getStringCellValue();
		    
		    
		    // display play of credential on consol
		    System.out.println(username+"\t\t"+Password);
		    // Handle exception (Invalid credintial)
		    try
		    {
		    	// login script
		    obj.url(driver);
		    	Thread.sleep(2000);
		    	obj.maximizeBrowser(driver);
		    	Thread.sleep(2000);
		    	
		    	obj.enterUsername(driver, username);
		    	Thread.sleep(2000);
		    	
		    	obj.enterPassword(driver, Password);
		    	Thread.sleep(2000);
		    	
		    	obj.clickOnLoginButton(driver);
		    	Thread.sleep(2000);
		    	//update test result
		    	System.out.println("Valid Credential");
		    //	System.out.println("");
		    	s.getRow(i).createCell(2).setCellValue("Valid Credential.");
		    }
		    catch(Exception e)
		    {
		    	System.out.println("Invalid Credential");
		    	//System.out.println(" ");
		    	s.getRow(i).createCell(2).setCellValue("Invalid Credential");
		    
		    }
		    }
		    // save the result
		    FileOutputStream out= new FileOutputStream ("./POI_FrameworksPara.xlsx");
		    w.write(out);
		    driver.close();
		    	

	}

}
